#include<stdio.h>
void ex1(){
    printf("This's our C programming course. \nWelcome to the first tutorial class.\n");
}