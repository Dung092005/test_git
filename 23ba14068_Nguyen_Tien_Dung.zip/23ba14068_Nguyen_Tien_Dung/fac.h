#include<stdio.h>
void ex1();
void ex2(int a,int b,int c);
int ex3(int a);
int ex4();

