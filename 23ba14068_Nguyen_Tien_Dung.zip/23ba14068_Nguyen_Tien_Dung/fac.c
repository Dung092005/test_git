#include<stdio.h>
#include"fac.h"
int main(){
    ex1();
    ex2(1,2,1);
    int a;
    scanf("%d",&a);
    printf("%d\n",ex3(a));
    int b ,c;
    scanf("%d %d",&b,&c);

    printf("%d",ex4(b,c));

}