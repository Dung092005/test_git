#include<stdio.h>
 
void ex2(int a,int b,int c){ 
    int x;
    scanf("%d",&x);
    int value = a*x*x + b*x + c; 
    printf("%d\n",value); 

} 
#sjdkasdasdjalskda